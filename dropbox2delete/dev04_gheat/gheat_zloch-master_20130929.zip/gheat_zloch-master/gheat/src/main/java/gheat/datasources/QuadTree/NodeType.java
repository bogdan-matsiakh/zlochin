package gheat.datasources.QuadTree;

public enum NodeType {
    EMPTY,
    LEAF,
    POINTER
}
