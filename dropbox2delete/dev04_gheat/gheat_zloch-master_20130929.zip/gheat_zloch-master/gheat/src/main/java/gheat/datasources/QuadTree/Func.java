package gheat.datasources.QuadTree;

public interface Func {
    public void call(QuadTree quadTree, Node node);
}
