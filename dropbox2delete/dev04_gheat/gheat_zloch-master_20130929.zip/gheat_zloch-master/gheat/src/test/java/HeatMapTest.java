import junit.framework.TestCase;


public class HeatMapTest extends TestCase {

    public void testOverloadedMethod() throws Exception {

//        ThemeManager.init("..\\res\\etc\\");
//        DataSource dataSource = new FileDataSource("..\\gheat\\points.txt");
//
//        DataManager dataManager = new DataManager(dataSource);
//        BufferedImage img = HeatMap.GetTile(dataManager, "classic", 5, 8, 12);
//
//
//        File outputFile = new File("C:\\Users\\va008pa\\Desktop\\image.png");
//        ImageIO.write(img, "PNG", outputFile);
    }


}
