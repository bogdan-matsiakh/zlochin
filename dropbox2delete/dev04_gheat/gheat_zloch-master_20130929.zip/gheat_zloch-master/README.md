gheat_zloch
===========

Original project: https://github.com/varunpant/GHEAT-JAVA

Original gheat server doesn't work properly. Some bugs need to be solved.

Launch App.java class in heatmaps project and open test.html file after that.

